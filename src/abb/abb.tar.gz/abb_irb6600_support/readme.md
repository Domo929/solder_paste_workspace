# abb_irb6600_support

## Overview

This package is part of the [ROS-Industrial][] program. See the main [abb][]
page on the ROS wiki for more information on usage.

## Supported Variants

- IRB 6600-225/2.55

## Deprecated

The unqualified IRB 6400 model will be removed in ROS-Lunar, please
use the abb_irb6640_support as a replacement.

[ROS-Industrial]: http://wiki.ros.org/Industrial
[abb]: http://wiki.ros.org/abb
